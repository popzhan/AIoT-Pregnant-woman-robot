#include <serial_node.hpp>

Robot_Transmit_Data_t vel_msg_transmit_data;
void vel_subscriver_callback(const geometry_msgs::TwistConstPtr& vel_msg)
{
    vel_msg_transmit_data.vx = vel_msg->linear.x;
    vel_msg_transmit_data.vy = vel_msg->linear.y;
    vel_msg_transmit_data.wz = vel_msg->angular.z;
    // ROS_INFO_STREAM("Serial got vel_msg from robot_move_node");
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "serial_node");
    robot_communication_t robot_serial;
    ROS_INFO("serial_node node has turned on");
    robot_serial.Control();
    return 0;
}

robot_communication_t::robot_communication_t()
{
    odom_publisher = n.advertise<nav_msgs::Odometry>("/odom",10);
    // Imu_publisher = n.advertise<sensor_msgs::Imu>("mobile_base/sensors/imu_data", 20);
    vel_subscriver = n.subscribe("/cmd_vel", 10, vel_subscriver_callback);

    // 串口参数服务器
    ros::NodeHandle private_nh("~");
    private_nh.param<std::string>("usart_port_name", usart_port_name, "/dev/serial_port");
    private_nh.param<int>("serial_baud_rate", serial_baud_rate, 115200);

    //TF广播器
    // timestamp_offset_ = this->declare_parameter("timestamp_offset", 0.0);
    // tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);

    try{
        robot_communication_serial.setPort(usart_port_name);
        robot_communication_serial.setBaudrate(serial_baud_rate);
        ROS_INFO_STREAM("robot_communication is trying to open serial port...");

        serial::Timeout _time = serial::Timeout::simpleTimeout(2000);
        robot_communication_serial.setTimeout(_time);
        robot_communication_serial.open();
    }catch(serial::IOException& e){
        ROS_ERROR_STREAM("robot_communication can not open serial port, please check the serial port cable!");
    }
    if(robot_communication_serial.isOpen()){
        ROS_INFO_STREAM("robot_communication open serial port successfully!");
    }

}


void robot_communication_t::Get_Serial_Data()  
{
    size_t data_size = sizeof(Robot_Receice_Data_t);  
    //初始化数据类型
    std::vector<uint8_t> full_message(data_size); 
    // //清除接收到的数据包
    // memset(&Receive_Data, 0 , data_size);

    try {
        // 读取header  
        if (robot_communication_serial.read(&full_message[0], 1) == 1) { // 检查是否确实读取了一个字节  
            if (full_message[0] == 0x5A) {  
                robot_communication_serial.read(&full_message[1], data_size-1);
                // 输出接收到的数据  
                //ROS_INFO_STREAM("Correct header: " << "0x" << std::hex << static_cast<int>(full_message[0]));  
                // std::stringstream ss;  
                // for (size_t i = 0; i < full_message.size(); i++) {  
                //     ss << "0x" << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(full_message[i]) << " ";  
                // }  
                // ROS_INFO_STREAM(ss.str());
                //压缩转换数据包格式
                Robot_Receice_Data_t packet = fromVector(full_message);
                //CRC校验
                bool crc_ok = crc16::Verify_CRC16_Check_Sum(reinterpret_cast<const uint8_t*>(&packet), data_size);

                // uint16_t check_sum = crc16::Get_CRC16_Check_Sum(reinterpret_cast<const uint8_t*>(&packet), data_size-2, 0xFFFF);
                // memcpy(&Receive_Data, &packet, data_size-1);
                // ROS_INFO_STREAM("header: " << std::hex << static_cast<int>(Receive_Data.header));  
                // ROS_INFO_STREAM("x: " << Receive_Data.x); // 假设x是float类型，直接输出  
                // ROS_INFO_STREAM("y: " << Receive_Data.y);  
                // ROS_INFO_STREAM("z: " << Receive_Data.z);  
                // ROS_INFO_STREAM("vx: " << Receive_Data.vx);  
                // ROS_INFO_STREAM("vy: " << Receive_Data.vy);  
                // ROS_INFO_STREAM("wz: " << Receive_Data.wz);  
                // // 如果checksum是CRC校验和的一部分，并且您想要输c出它（通常不是必须的）  
                // ROS_INFO_STREAM("CRC check: " << std::hex << static_cast<uint16_t>(check_sum));  
                
                if (crc_ok) {  
                    memcpy(&Receive_Data, &packet, data_size);
                    //ROS_INFO_STREAM("CRC correct! " << std::hex << static_cast<uint16_t>(Receive_Data.checksum));
                } else {  
                    ROS_ERROR_STREAM("CRC error!");  
                }
            } else {  
                // 错误头帧  
                ROS_ERROR_STREAM("Invalid header: " << "0x" << std::hex << static_cast<int>(full_message[0]));  
            }  
        } else {
            // 读取header失败  
            ROS_ERROR_STREAM("Failed to read header.");  
        }  
    }catch (const std::exception& ex) {
        ROS_ERROR_STREAM("Error while receiving data: " << ex.what());
    }
}

void robot_communication_t::Send_Serial_Data()
{
  try {
    Transmit_Data.header = 0xA5;
    Transmit_Data.vx = -vel_msg_transmit_data.vx;
    Transmit_Data.vy = -vel_msg_transmit_data.vy;
    Transmit_Data.wz = vel_msg_transmit_data.wz;
    crc16::Append_CRC16_Check_Sum(reinterpret_cast<uint8_t *>(&Transmit_Data), sizeof(Transmit_Data));
    
    std::vector<uint8_t> data = toVector(Transmit_Data);
    robot_communication_serial.write(data);
    // memset(&Transmit_Data, 0, sizeof(Transmit_Data));
    // memset(&vel_msg_transmit_data, 0, sizeof(vel_msg_transmit_data));
    //ROS_INFO_STREAM("Data sent");
  } catch (const std::exception & ex) {
    ROS_ERROR_STREAM("Error while sending data: " << ex.what());
  }
}

void robot_communication_t::Control()
{
    _Now = ros::Time::now();
	ros::Rate r(10);
    while(ros::ok())
    {
        Get_Serial_Data();
        Send_Serial_Data();
        Public_Odom();
        // Public_IMUSenser();
        _Last_Time = ros::Time::now();
        // ROS_INFO_STREAM("Task end");
	    r.sleep();
        ros::spinOnce();
    }
}

void robot_communication_t::Public_IMUSenser()
{
    Imu_Data_Pub.header.frame_id = "gyro_link";
    Imu_Data_Pub.header.stamp = ros::Time::now();
    geometry_msgs::Quaternion Imu_quat = tf::createQuaternionMsgFromYaw(Receive_Data.z);
    Imu_Data_Pub.orientation = Imu_quat;
    Imu_Data_Pub.orientation_covariance[0] = 0;
    Imu_Data_Pub.orientation_covariance[4] = 0;
    Imu_Data_Pub.orientation_covariance[8] = 0;
    Imu_publisher.publish(Imu_Data_Pub);
}

void robot_communication_t::Public_Odom()
{
    odom.header.frame_id = "odom";
    odom.header.stamp = ros::Time::now();
    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(Receive_Data.z);
    odom.pose.pose.position.x = Receive_Data.x;
    odom.pose.pose.position.y = Receive_Data.y;
    odom.pose.pose.position.z = 0;
	odom.pose.pose.orientation.z = 0;
    odom.pose.pose.orientation = odom_quat;

    odom.twist.twist.linear.x = Receive_Data.vx;
    odom.twist.twist.linear.y = Receive_Data.vy;
    odom.twist.twist.angular.z = Receive_Data.wz;

    odom_publisher.publish(odom);
}


robot_communication_t::~robot_communication_t()
{
    Transmit_Data.header = 0xA5;
    Transmit_Data.vx = 0;
    Transmit_Data.vy = 0;
    Transmit_Data.wz = 0;
    crc16::Append_CRC16_Check_Sum(reinterpret_cast<uint8_t *>(&Transmit_Data), sizeof(Transmit_Data));
    
    std::vector<uint8_t> data = toVector(Transmit_Data);
    robot_communication_serial.write(data);
    ROS_INFO_STREAM("Data sent");
    ROS_INFO_STREAM("Ros node finished");
}
