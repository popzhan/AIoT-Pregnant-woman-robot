#include <ros/ros.h>
#include <serial/serial.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Imu.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include "crc.hpp"
#include <tf/tf.h>

#include <memory>
#include <stddef.h>

struct Robot_Receice_Data_t
{
    uint8_t header = 0x5A;
    float x;
    float y;
    float z;

    float vx;
    float vy;
    float wz;
    uint16_t checksum = 0;
}__attribute__((packed));

struct Robot_Transmit_Data_t
{
    uint8_t header = 0xA5;
    float vx;
    float vy;
    float wz;
    uint16_t checksum = 0;
}__attribute__((packed));

class robot_communication_t
{
    public:
    robot_communication_t();
    ~robot_communication_t();
        void Control();
        //串口
         Robot_Receice_Data_t Receive_Data;      //接受数据
        Robot_Transmit_Data_t Transmit_Data;    //发送数据
    private:
        void Public_Odom();
        void Public_IMUSenser();
        void Get_Serial_Data();
        void Send_Serial_Data();

        //串口
        serial::Serial robot_communication_serial;
        std::string usart_port_name;
        int serial_baud_rate;

        //节点运行参数
        ros::Time _Now, _Last_Time;
        ros::NodeHandle n;
        nav_msgs::Odometry odom;
        sensor_msgs::Imu Imu_Data_Pub;
        ros::Publisher odom_publisher;
        ros::Publisher Imu_publisher;
        ros::Subscriber vel_subscriver;
};

inline Robot_Receice_Data_t fromVector(const std::vector<uint8_t> & data)
{
  Robot_Receice_Data_t packet;
  std::copy(data.begin(), data.end(), reinterpret_cast<uint8_t *>(&packet));
  return packet;
}

inline std::vector<uint8_t> toVector(const Robot_Transmit_Data_t & data)
{
  std::vector<uint8_t> packet(sizeof(Robot_Transmit_Data_t));
  std::copy(
    reinterpret_cast<const uint8_t *>(&data),
    reinterpret_cast<const uint8_t *>(&data) + sizeof(Robot_Transmit_Data_t), packet.begin());
  return packet;
}
