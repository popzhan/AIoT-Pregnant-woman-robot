#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <tf2_ros/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>

class robot_move_t
{
    public:
    robot_move_t();
        void Control();
    private:
        void Publish_Vel();

        //TF坐标变换

        //发布消息类型
        ros::NodeHandle n;
        ros::Publisher robot_vel_pub;   //发布者
        ros::Subscriber robot_odom_sub;   //订阅者
        geometry_msgs::Twist vel_msg;
};