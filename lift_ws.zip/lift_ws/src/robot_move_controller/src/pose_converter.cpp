#include <ros/ros.h>  
#include <geometry_msgs/PoseWithCovarianceStamped.h>  
#include <geometry_msgs/Pose.h>  
  
class PoseConverter  
{  
private:  
    ros::NodeHandle nh_;  
    ros::Subscriber sub_;  
    ros::Publisher pose_pub_;  
  
    // 回调函数  
    void poseWithCovarianceStampedCallback(const geometry_msgs::PoseWithCovarianceStampedConstPtr& msg)  
    {  
        // 提取Pose数据  
        const geometry_msgs::Pose& pose = msg->pose.pose;  
  
        // 发布Pose数据  
        pose_pub_.publish(pose);  
  
        // 打印Pose数据  
        ROS_INFO("Published Pose: Position (x, y, z) = (%.2f, %.2f, %.2f), Orientation (x, y, z, w) = (%.2f, %.2f, %.2f, %.2f)",  
                 pose.position.x, pose.position.y, pose.position.z,  
                 pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w);  
    }  
  
public:  
    PoseConverter()  
        : nh_(),  
          sub_(nh_.subscribe("/amcl_pose", 10, &PoseConverter::poseWithCovarianceStampedCallback, this)),  
          pose_pub_(nh_.advertise<geometry_msgs::Pose>("/pose", 10))  
    {  
        // 构造函数中不需要其他操作，订阅和发布已在初始化列表中完成  
    }  
  
    // 运行ROS节点的主要函数  
    void run()  
    {  
        // 进入ROS循环，等待回调  
        ros::spin();  
    }  
};  
  
int main(int argc, char **argv)  
{  
    // 初始化ROS节点  
    ros::init(argc, argv, "pose_converter");  
  
    // 创建PoseConverter对象并运行  
    PoseConverter converter;  
    converter.run();  
  
    return 0;  
}
