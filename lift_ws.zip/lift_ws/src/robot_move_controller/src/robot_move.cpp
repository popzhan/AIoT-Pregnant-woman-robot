#include "robot_move.hpp"

//机器人odom获取和tf发布
void robot_odom_sub_callback(const nav_msgs::OdometryConstPtr& odom)
{
    static tf2_ros::TransformBroadcaster br;  
    geometry_msgs::TransformStamped transformStamped;  
  
    transformStamped.header.stamp = odom->header.stamp;  
    transformStamped.header.frame_id = "odom";
    transformStamped.child_frame_id = "base_footprint";

    transformStamped.transform.translation.x = odom->pose.pose.position.x;  
    transformStamped.transform.translation.y = odom->pose.pose.position.y;  
    transformStamped.transform.translation.z = odom->pose.pose.position.z; 

    transformStamped.transform.rotation =  odom->pose.pose.orientation;

    br.sendTransform(transformStamped);  
    // ROS_INFO_STREAM("Odom TF broadcaster created");
}



int main(int argc, char** argv)
{
    ros::init(argc, argv, "robot_move");
    robot_move_t robot_move;
    robot_move.Control();
    return 0;
}

robot_move_t::robot_move_t()
{
    robot_vel_pub  = n.advertise<geometry_msgs::Twist> ("/cmd_vel", 10);
    robot_odom_sub = n.subscribe("/odom", 10, robot_odom_sub_callback);
}

void robot_move_t::Control()
{
    ros::Rate r(1000);
    while(ros::ok())
    {
        // Publish_Vel();
        // r.sleep();
        // ROS_INFO_STREAM("Robot robot_move_node published");
        ros::spin();
    }
}

void robot_move_t::Publish_Vel()
{
    vel_msg.linear.x = 1.0;
    vel_msg.linear.y = 0;
    vel_msg.angular.z = 0;

    robot_vel_pub.publish(vel_msg);
}
